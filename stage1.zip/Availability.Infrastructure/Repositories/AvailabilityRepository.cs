// AvailabilityRepository.cs
using Availability.Domain.Interfaces;


namespace Availability.Infrastructure.Repositories
{
    public class AvailabilityRepository : IAvailabilityRepository
    {
        // ...
    }
}

