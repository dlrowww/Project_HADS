﻿namespace Availability.Infrastructure;

public class Class1
{

}
