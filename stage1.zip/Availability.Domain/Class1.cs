﻿namespace Availability.Domain;

public class Class1
{

}
