// IAvailabilityRepository.cs
using Availability.Domain.Interfaces;


namespace Availability.Domain.Interfaces
{
    public interface IAvailabilityRepository
    {
        // ...
    }
}

