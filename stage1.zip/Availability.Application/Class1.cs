﻿namespace Availability.Application;

public class Class1
{

}
